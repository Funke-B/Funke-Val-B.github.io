# Portfolio Site

A single-page portfolio: `index.html` holds the layout and styling, `content.js` holds everything editable (text, projects, education, certifications, links). You should only need to touch `content.js` for routine updates.

## Still worth checking

- `truecount.link` currently points at a claude.ai artifact link. That only works for visitors if the artifact has been shared/published publicly — otherwise they'll hit an access error. Worth swapping for a real site, a one-pager, or a LinkedIn page once you have one.
- Most projects have an empty `links: []`. Add `{ label: "View on GitHub", url: "https://github.com/..." }` entries once you have a repo or write-up for that project, and they'll render automatically (the Maji Ndogo project already has its real link).
- Your photo is in `imgs/profile.jpg` — swap that file for a different one anytime, no code changes needed, as long as the new file keeps the same name.

## Deploying to GitHub Pages (as your own repo)

1. Create a new repository on GitHub named exactly `Funke-B.github.io` (this is what makes it a user-page site, served at that URL — skip this step if you're adding it to an existing repo instead).
2. Upload `index.html`, `content.js`, and the `imgs` folder to the root of that repo (drag-and-drop on GitHub's web UI works fine, or `git add`/`commit`/`push` if you're using Git locally).
3. In the repo's **Settings → Pages**, set the source to the `main` branch, root folder.
4. Give it a minute or two — your site will be live at `https://funke-b.github.io/`.

## Notes on this build

- Design is original — inspired by the structure of the reference site you shared (sticky nav, hero, timeline, live GitHub stats, filterable projects, credentials, contact), with content drawn from your real work: the ALX Maji Ndogo case study, the GlowHouse Cosmetics segmentation module, the Lumora Skincare workbook, and the Hush'D Makeover inventory report.
- The GitHub stats and contribution graph are live — they pull from `https://api.github.com` and `ghchart.rshah.org` using your GitHub username at page load, so no manual updating needed there.
- The contact form uses a plain `mailto:` link (opens the visitor's email client) instead of a third-party form service — no account or API key required. If you'd rather have messages land directly without opening an email client, a free service like Formspree or EmailJS can be dropped in later.
- The Credentials section is split into **Education** (your ND and HND from Auchi Polytechnic) and **Professional Certifications & Training** (ACISCM, ACIWM, CILSCM PGD, CPIM) — kept separate since they're different kinds of credential.
